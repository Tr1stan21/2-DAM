package utils;

import model.Producto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UtilFicherosCSV {

    /**
     * Lee un archivo csv y devuelve una lista con cada linea
     *
     * @param nombrefichero ruta del fichero CSV
     * @return linesCsv lista con cada línea del fichero CSV
     */
    private ArrayList<String> readCsv(String nombrefichero) {
        ArrayList<String> linesCsv = new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader(nombrefichero))){
            String line;
            reader.readLine(); //Saltar cabecera
            while((line = reader.readLine()) != null) {
                linesCsv.add(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return linesCsv;
    }

    /**
     * Lee un archivo csv con objetos Producto y devuelve una lista con cada Producto
     *
     * @param nombrefichero fichero CSV con productos
     * @return productos lista de productos
     */
    public List<Producto> importarProductosCSV(String nombrefichero){
        List<Producto> productos = new ArrayList<>();
        for(String line : readCsv(nombrefichero)){
            String[] datosProductos = line.trim().split(";");
            productos.add(new Producto(Integer.parseInt(datosProductos[0]),datosProductos[1],Double.parseDouble(datosProductos[2]), Integer.parseInt(datosProductos[3])));
        }
        return productos;
    }
}
