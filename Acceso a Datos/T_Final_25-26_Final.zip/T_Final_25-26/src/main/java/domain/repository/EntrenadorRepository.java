package domain.repository;

import domain.model.Entrenador;

public interface EntrenadorRepository extends BaseRepository<Entrenador, Long> {
}
