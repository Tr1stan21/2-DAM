package domain.repository;

import domain.model.Entrenamiento;

public interface EntrenamientoRepository extends BaseRepository<Entrenamiento, String> {
}
