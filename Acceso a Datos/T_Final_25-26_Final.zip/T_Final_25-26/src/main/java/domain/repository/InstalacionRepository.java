package domain.repository;

import domain.model.Instalacion;

public interface InstalacionRepository extends BaseRepository<Instalacion, Long> {
}
