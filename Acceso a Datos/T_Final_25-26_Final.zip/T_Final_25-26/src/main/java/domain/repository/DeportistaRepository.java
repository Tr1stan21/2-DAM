package domain.repository;

import domain.model.Deportista;

public interface DeportistaRepository extends BaseRepository<Deportista, String> {
}
