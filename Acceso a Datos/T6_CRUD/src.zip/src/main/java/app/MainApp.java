package app;

import dao.impl.CityDaoImpl;

import java.sql.SQLException;

public class MainApp {
    public static void main(String[] args) throws SQLException {
        CityDaoImpl c = new CityDaoImpl();

        System.out.println(c.getCityById(4).toString());
    }
}
