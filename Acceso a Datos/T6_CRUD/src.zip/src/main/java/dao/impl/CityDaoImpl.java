package dao.impl;

import connection.DatabaseConnection;
import dao.CityDao;
import models.City;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CityDaoImpl implements CityDao {

    private static final CityDaoImpl instance;

    static {
        instance = new CityDaoImpl();
    }

    public CityDaoImpl(){}

    public static CityDaoImpl getInstance() {
        return instance;
    }

    @Override
    public void addCity(City city) throws SQLException {
        String query = "INSERT INTO city (countryCode, district, name, population) VALUES (?, ?, ?, ?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(query)) {
            ps.setString(1, city.getCountryCode());
            ps.setString(2, city.getDistrict());
            ps.setString(3, city.getName());
            ps.setInt(4, city.getPopulation());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public City getCityById(int id) throws SQLException {
        String query = "SELECT id, countryCode, district, id, name, population FROM city WHERE id = ?";

        try(Connection c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new City(
                        rs.getString("countryCode"),
                        rs.getString("district"),
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("population")
                );
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public List<City> getAllCities() throws SQLException {
        List<City> allCities = new ArrayList<>();
        String query = "SELECT id, countryCode, district, id, name, population FROM city";

        try(Connection c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(query)) {

            ResultSet rs = ps.executeQuery(); {
                while(rs.next()) {
                    allCities.add(new City(
                            rs.getString("countryCode"),
                            rs.getString("district"),
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getInt("population")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return allCities;
    }

    @Override
    public void updateCity(City city) throws SQLException {

    }

    @Override
    public void deleteCity(int id) throws SQLException {

    }

}
