package dao;

import models.City;

import java.sql.SQLException;
import java.util.List;

public interface CityDao {
    void addCity(City city) throws SQLException;

    City getCityById(int id) throws SQLException;

    List<City> getAllCities() throws SQLException;

    void updateCity(City city) throws SQLException;

    void deleteCity(int id) throws SQLException;

}
