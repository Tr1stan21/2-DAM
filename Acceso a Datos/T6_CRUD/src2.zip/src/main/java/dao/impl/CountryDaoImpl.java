package dao.impl;

public class CountryDaoImpl {
}
