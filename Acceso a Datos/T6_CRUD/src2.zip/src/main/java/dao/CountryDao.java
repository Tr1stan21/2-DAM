package dao;

public interface CountryDao {
}
