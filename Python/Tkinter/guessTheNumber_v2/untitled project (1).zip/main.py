# This code is generated using PyUIbuilder: https://pyuibuilder.com

import os
import tkinter as tk
from tkinter import ttk

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


main = tk.Tk()
main.title("Main Window")
main.config(bg="#E4E2E2")
main.geometry("672x511")


style = ttk.Style(main)
style.theme_use("clam")


style.configure("title.TLabel", background="#e4e2e2", foreground="#000", relief=tk.FLAT, font=("System", 32, "bold"), anchor="center")
title = ttk.Label(master=main, text="Adivina el número", style="title.TLabel")
title.configure(anchor="center")
title.grid(row=0, column=0)

style.configure("description.TLabel", background="#E4E2E2", foreground="#000", font=("", 18), anchor="center")
description = ttk.Label(master=main, text="Estoy pensando un número del 1 al 100", style="description.TLabel")
description.configure(anchor="center")
description.grid(row=1, column=0)

frame = tk.Frame(master=main)
frame.config(bg="#EDECEC", width=340, height=70)
frame.grid(row=3, column=0)

style.configure("button.TButton", background="#E4E2E2", foreground="#000", font=("", 16))
style.map("button.TButton", background=[("active", "#E4E2E2")], foreground=[("active", "#000")])

button = ttk.Button(master=frame, text="Button", style="button.TButton")
button.pack(ipadx=10, ipady=10, side=tk.RIGHT, anchor='n')

style.configure("entry.TEntry", fieldbackground="#fff", foreground="#000", font=("Symbol", 16))

entry = ttk.Entry(master=frame, style="entry.TEntry")
entry.pack(ipadx=8, ipady=8, side=tk.LEFT, anchor='n')

style.configure("tries_left.TLabel", background="#E4E2E2", foreground="#000", font=("", 18), anchor="center")
tries_left = ttk.Label(master=main, text="Te quedan 10 intentos", style="tries_left.TLabel")
tries_left.configure(anchor="center")
tries_left.grid(row=2, column=0)

style.configure("info.TLabel", background="#E4E2E2", foreground="#000", font=("System", 20, "bold"), anchor="center")
info = ttk.Label(master=main, text="Prueba un número más", style="info.TLabel")
info.configure(anchor="center")
info.grid(row=4, column=0)


main.mainloop()