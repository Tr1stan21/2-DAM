import pyautogui
import time

pyautogui.hotkey('Win', 'r')

pyautogui.write('mspaint')
pyautogui.press('enter')
