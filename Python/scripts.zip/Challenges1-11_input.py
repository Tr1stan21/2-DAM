#Ej1 y 2
name = input("Nombre: ")
apellido = input("Apellido: ")

print("Hello", name, apellido)

#Ej3
print("What do you call a bear with no teeth?"+"\n"+"A gummy bear!")

#Ej4
num2 = int(input("num1: "))
num1 = int(input("num2: "))

print(num1 + num2)

#Ej 5
num3 = int(input("Multiplicador: "))
print((num1+num2)*num3)

#Ej 6
pizza = int(input("Trozos de pizza: "))
pizzaComida = int(input("Trozos de pizza comido: "))
print("Pizza restante", pizza-pizzaComida)

#Ej 7
edad = int(input("Edad: "))
print("Próximo cumpleaños tendrás: ", edad+1)

#Ej 8
total = int(input("Total cena: "))
comensales = int(input("Comensales: "))
print("Cada uno paga:", total/comensales)

#Ej 9
numDias = int(input("Numero de días: "))
print("Horas:", numDias*24, "Minutos:", numDias*24*60, "Segundos:", numDias*24*60*60)

#Ej 10
peso = int(input("Tu peso: "))
print("Pesas:", peso*2.204, "libras")

#Ej 11
mayor100 = int(input("Numero mayor que 100: "))
menor10 = int(input("Numero menor que 10: "))
print("El numero", menor10, "está", mayor100/menor10, "veces en", mayor100)

