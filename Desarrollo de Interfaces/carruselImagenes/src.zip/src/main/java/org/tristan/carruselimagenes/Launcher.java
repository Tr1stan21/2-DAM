package org.tristan.carruselimagenes;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(MainApp.class, args);
    }
}
