package master;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SumadorMaster {
    public static void main(String[] args) throws IOException {
        List<Process> processes = new ArrayList<>();
        List<Long> startTimes = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inicio del intervalo: ");
        int start = 1; //Integer.parseInt(scanner.next());
        System.out.println("Final del intervalo: ");
        int end = 100; //Integer.parseInt(scanner.next());
        System.out.println("Tipo de número: ");
        String tipoNumero = "impar"; //scanner.next();
        System.out.println("Número de procesos a realizar: ");
        int numOfProcesses = 3; //Integer.parseInt(scanner.next());

        if(start > 0 && end > start && (tipoNumero.equals("todos" )|| tipoNumero.equals("par") || tipoNumero.equals("impar"))) {
            launchProcessesInBatches(start, end, tipoNumero, numOfProcesses, processes, startTimes);
        }
        else {
            System.out.println("mal");
        }

        readProcesses(processes, startTimes);
    }

    private static void readProcesses(List<Process> processes, List<Long> startTimes) {
        int total = 0;
        double end = 0;
        for(int i = 0; i < processes.size(); i++) {
            try (
                    BufferedReader fromChild = new BufferedReader(new InputStreamReader(processes.get(i).getInputStream()))
            ) {
                total += Integer.parseInt(fromChild.readLine());
                end = System.nanoTime();
                double seconds = (end - startTimes.get(i)) /1_000_000_000.0;
                System.out.println("    - Tiempo total del proceso "+ (i+1) +": "+ seconds +"s");

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("Tiempo total del programa: "+ ((end - startTimes.getFirst())/1_000_000_000.0) +" segundos");
        System.out.println("Resultado final: "+ total);
    }

    public static void launchProcess(int start, int end, String tipoNumero, List<Process> processes, List<Long> startTimes) throws IOException {
        ProcessBuilder pb = new ProcessBuilder("java", "-jar", "SumadorProcess.jar");
        Process process = pb.start();
        processes.add(process);
        startTimes.add(System.nanoTime());
        try (BufferedWriter toChild = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()))) {
            toChild.write(String.valueOf(start));
            toChild.newLine();
            toChild.write(String.valueOf(end));
            toChild.newLine();
            toChild.write(tipoNumero);
            toChild.newLine();
            toChild.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private static void launchProcessesInBatches(int start, int end, String tipoNumero, int numOfProcesses, List<Process> processes, List<Long> startTimes) throws IOException {
        int difference = end - start + 1;
        int batchSize = difference / numOfProcesses;
        int finalEnd = start + difference - 1;

        for(int i = 0; i < numOfProcesses; i++) {
            if (i == numOfProcesses - 1) {
                end = finalEnd;
            } else {
                end = start + batchSize - 1;
            }
            launchProcess(start, end, tipoNumero, processes, startTimes);
            start = end + 1;
        }
    }

}
