package threads;

import utils.PrimeUtils;

import java.util.List;

public class PrimeInRangeThread extends Thread {
    private final long start;
    private final long end;
    private final List<Long> allPrimesInRange;

    public PrimeInRangeThread(long start, long end, List<Long> allPrimeNumbers) {
        this.start = start;
        this.end = end;
        this.allPrimesInRange = allPrimeNumbers;
    }

    @Override
    public void run() {
        PrimeUtils utils = new PrimeUtils();
        List<Long> primeNumbers = utils.primeNumbersInRange(start, end);
        allPrimesInRange.addAll(primeNumbers);
    }
}
